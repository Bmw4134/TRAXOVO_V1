// kaizen_assistant_core.ts
import { useEffect } from 'react';
import { useGoalTracker } from './lib/goal_tracker';
import { useChartRenderer } from './lib/chart_renderer';
import { useStrictValidator } from './lib/strict_validator';
import { useWebSocketStream } from './lib/metrics_stream';
import { AuthWrapper } from './lib/auth_wrapper';
import { useFirebaseSync } from './lib/firebase_sync';
import { usePromptDNA } from './lib/prompt_dna';
import { useLLMTestHarness } from './lib/llm_test_harness';
import { useWidgetCoordinator } from './lib/widget_coordinator';

export default function KaizenAssistantCore({ children }) {
  useStrictValidator();
  useGoalTracker();
  useChartRenderer();
  useWebSocketStream();
  useFirebaseSync();
  usePromptDNA();
  useLLMTestHarness();
  useWidgetCoordinator();

  return <AuthWrapper>{children}</AuthWrapper>;
}

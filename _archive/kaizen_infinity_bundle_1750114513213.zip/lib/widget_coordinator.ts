// lib/widget_coordinator.ts
import { useEffect } from 'react';

export function useWidgetCoordinator() {
  useEffect(() => {
    const bus = new EventTarget();
    window.kaizenWidgetBus = bus;

    const syncMessage = (e: CustomEvent) => {
      const { widgetId, payload } = e.detail;
      const updateEvent = new CustomEvent(`update:${widgetId}`, { detail: payload });
      bus.dispatchEvent(updateEvent);
    };

    window.addEventListener('sync_widget_data', syncMessage as EventListener);
    return () => window.removeEventListener('sync_widget_data', syncMessage as EventListener);
  }, []);
}

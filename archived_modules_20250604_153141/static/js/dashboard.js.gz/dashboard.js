document.addEventListener("DOMContentLoaded", function () {
  const tooltipTriggerList = Array.from(
    document.querySelectorAll('[data-bs-toggle="tooltip"]'),
  );
  tooltipTriggerList.forEach((tooltipTriggerEl) => {
    new bootstrap.Tooltip(tooltipTriggerEl);
  });
  const filterForm = document.getElementById("filter-form");
  if (filterForm) {
    filterForm.addEventListener("submit", function (e) {
      e.preventDefault();
      applyFilters();
    });
  }
  const clearFiltersBtn = document.getElementById("clear-filters");
  if (clearFiltersBtn) {
    clearFiltersBtn.addEventListener("click", function () {
      document.getElementById("status-filter").value = "all";
      document.getElementById("category-filter").value = "all";
      document.getElementById("location-filter").value = "all";
      applyFilters();
    });
  }
  const searchInput = document.getElementById("search-input");
  if (searchInput) {
    searchInput.addEventListener("keyup", function () {
      const searchValue = this.value.toLowerCase();
      function initRealtimeCharts() {
        const ctx = document.getElementById("realtimeChart").getContext("2d");
        const realtimeChart = new Chart(ctx, {
          type: "line",
          data: {
            datasets: [
              {
                label: "Live Data Stream",
                fill: false,
                borderColor: "rgb(75, 192, 192)",
                data: [],
              },
            ],
          },
        });
        function updateChartData() {
          fetch("/api/metrics")
            .then((response) => response.json())
            .then((data) => {
              const newDataPoint = {
                x: new Date(),
                y: data.data.estimated_revenue,
              };
              realtimeChart.data.datasets[0].data.push(newDataPoint);
              realtimeChart.update();
            })
            .catch(console.error);
        }
        setInterval(updateChartData, 5000); // update every 5 seconds
      }
      document.addEventListener("DOMContentLoaded", function () {
        initRealtimeCharts();
      });
      const assetCards = document.querySelectorAll(".asset-card");
      assetCards.forEach(function (card) {
        const assetText = card.textContent.toLowerCase();
        if (assetText.includes(searchValue)) {
          card.style.display = "";
        } else {
          card.style.display = "none";
        }
      });
    });
  }
});
function applyFilters() {
  const statusFilter = document.getElementById("status-filter").value;
  const categoryFilter = document.getElementById("category-filter").value;
  const locationFilter = document.getElementById("location-filter").value;
  window.location.href = `/?status=${statusFilter}&category=${categoryFilter}&location=${locationFilter}`;
}
function toggleDetails(assetId) {
  const detailsElement = document.getElementById(`details-${assetId}`);
  if (detailsElement) {
    if (
      detailsElement.style.display === "none" ||
      !detailsElement.style.display
    ) {
      detailsElement.style.display = "block";
    } else {
      detailsElement.style.display = "none";
    }
  }
}

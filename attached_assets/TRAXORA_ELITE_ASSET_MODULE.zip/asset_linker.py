
def link_vin_to_assets(asset_list, vin_lookup):
    for asset in asset_list:
        if 'vin' in asset:
            asset['vin_data'] = vin_lookup(asset['vin'])
    return asset_list

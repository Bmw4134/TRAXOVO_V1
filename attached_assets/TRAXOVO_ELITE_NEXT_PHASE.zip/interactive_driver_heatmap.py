# Module: Interactive Driver Performance Heatmap
# Visualizes performance by skill across timecards and GPS logs.
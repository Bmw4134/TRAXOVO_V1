// Expand/collapse logic
function toggleDriverDetails() {}
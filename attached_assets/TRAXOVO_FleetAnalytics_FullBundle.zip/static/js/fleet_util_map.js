
// Basic pin logic for TRAXOVO Smart Map
function plotFleetPins(data) {
    data.forEach(asset => {
        console.log('Plotting', asset.asset_id, asset.usage);
    });
}

# Frontend Sync Patch - TRAXOVO

Use this when Replit confirms a UI fix but it doesn’t reflect live.

## Step 1: Run Sync Helper
```bash
python3 frontend_sync_helper.py
```

## Step 2: Flush Frontend
```bash
bash flush_frontend.sh
```

## Step 3: Restart App
```bash
python3 app.py
```

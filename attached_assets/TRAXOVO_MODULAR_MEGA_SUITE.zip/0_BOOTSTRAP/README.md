
# TRAXOVO Modular Mega Suite

- Fully compartmentalized
- Safe to drop into Replit root
- Includes loader and tab autowiring

Run:
$ python master_loader.py


#!/bin/bash
# kaizen-validate.sh

echo "Running Kaizen Self-Test Validation..."

python3 -c "
import subprocess
print('📁 Checking flask routes...')
subprocess.run(['flask', 'routes'])

print('\n🧪 Testing Attendance Workflow route...')
import requests
try:
    r = requests.get('http://localhost:5000/attendance-workflow')
    print('Status Code:', r.status_code)
    print('Content contains:', 'Attendance Workflow' in r.text and 'Start Workflow' in r.text)
except Exception as e:
    print('⚠️ Route test failed:', e)

print('\n✅ Validation complete. Use agent prompt to run a full UI sync if needed.')
"

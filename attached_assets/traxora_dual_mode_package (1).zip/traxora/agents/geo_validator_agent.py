def validate_location(gps_coords, geofence):
    # Stub logic
    return gps_coords in geofence

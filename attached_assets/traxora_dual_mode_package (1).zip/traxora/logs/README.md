This directory holds runtime logs:
- skipped_rows.jsonl: JSON line-delimited log of rows that were filtered/skipped during ingestion.
- system.log (future): Capture app-wide runtime events for diagnostics.

Ensure this is mounted or persisted in Replit config.

import os

def is_dev_mode():
    return os.getenv("REPLIT_PROFILE", "dev") == "dev"

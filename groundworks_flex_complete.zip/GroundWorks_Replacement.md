
# GroundWorks Replacement Module
Includes: Attendance route, dashboard UI, admin-only navigation link.

- `attendance_workflow.py` → route and blueprint
- `dashboard.html` → UI template
- `admin_embed_snippet.html` → Admin-only sidebar link

Drop all into your Replit project and register `attendance_bp` in `app.py`:
```python
from attendance_workflow import attendance_bp
app.register_blueprint(attendance_bp, url_prefix="/attendance-workflow")
```

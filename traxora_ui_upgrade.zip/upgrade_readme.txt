GENIUS CORE PHASE III: UI UNIFICATION & ROUTE STABILIZATION

1. Place 'base.html', 'navbar.html', and 'footer.html' in your templates directory.
2. Update all templates to extend from base.html.
3. Add the route validator to your app and call it with expected route list on init.
4. (Optional) Add caching using flask_caching for heavy views.

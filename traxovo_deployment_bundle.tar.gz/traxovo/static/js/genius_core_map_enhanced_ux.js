/**
 * TRAXORA GENIUS CORE | Enhanced Map UX
 * 
 * This module extends the Map Agent with advanced UX improvements:
 * - Quick-action job reassignment
 * - Division-based color coding
 * - Collapsible legend panel
 * - Hover-to-view summaries
 * - Sticky sidebar for desktop
 */

class EnhancedMapUX {
    constructor() {
        // Check if required components exist
        if (!window.GeniusCore) {
            console.error('GENIUS CORE not available. Enhanced Map UX initialization aborted.');
            return;
        }
        
        if (!window.EnhancedMap) {
            console.error('Enhanced Map not available. Enhanced Map UX initialization aborted.');
            return;
        }
        
        this.geniusCore = window.GeniusCore;
        this.baseMap = window.EnhancedMap;
        
        // Division colors (used for asset markers)
        this.divisionColors = {
            'DIV 2': '#3366FF', // DFW - Blue
            'DIV 4': '#FF3333', // HOU - Red
            'DIV 3': '#33CC33', // WT - Green
            'DIV 8': '#FFCC00', // TEXDIST - Yellow
            'UNASSIGNED': '#999999' // Unassigned or test - Gray
        };
        
        // Job to division mapping (for determining colors)
        this.jobToDivision = {
            '2023-032': 'DIV 2',
            '2024-019': 'DIV 2',
            'DFW-YARD': 'DIV 2',
            '2023-007': 'DIV 3',
            'HOU-YARD': 'DIV 4',
            '2024-012': 'DIV 2',
            '2024-004': 'DIV 8'
        };
        
        // Set up event delegation for map interactions
        this.setupEventDelegation();
        
        // Register with GENIUS CORE
        this.mapUXAgent = {
            id: 'EnhancedMapUX',
            
            handleMessage(message) {
                switch (message.type) {
                    case 'quick-reassign-job':
                        return window.MapUX.quickReassignJob(
                            message.payload.assetId,
                            message.payload.jobNumber
                        );
                        
                    case 'enhance-asset-marker':
                        return window.MapUX.enhanceAssetMarker(
                            message.payload.assetId,
                            message.payload.options
                        );
                        
                    case 'toggle-legend':
                        return window.MapUX.toggleLegend(
                            message.payload.visible
                        );
                        
                    case 'toggle-sticky-sidebar':
                        return window.MapUX.toggleStickySidebar(
                            message.payload.enabled
                        );
                        
                    default:
                        return { status: 'unknown-message-type' };
                }
            }
        };
        
        this.geniusCore.registerAgent('EnhancedMapUX', this.mapUXAgent);
        
        // Enhance the map UI
        this.enhanceMapUI();
        
        console.log('Enhanced Map UX initialized');
    }
    
    setupEventDelegation() {
        // Set up event delegation for map interactions
        document.addEventListener('click', (event) => {
            // Handle quick-action job reassignment
            if (event.target.classList.contains('reassign-job-button')) {
                const assetId = event.target.getAttribute('data-asset-id');
                this.showJobReassignDialog(assetId);
            }
            
            // Handle other map actions
            if (event.target.classList.contains('toggle-legend-button')) {
                this.toggleLegend();
            }
            
            if (event.target.classList.contains('toggle-sidebar-button')) {
                this.toggleStickySidebar();
            }
        });
    }
    
    enhanceMapUI() {
        // Add necessary UI elements for enhanced functionality
        this.addLegendPanel();
        this.makeFiltersStickyForDesktop();
        this.enhanceAssetPopups();
        this.addHoverEffects();
        
        // Register for map events to apply division colors
        if (this.baseMap.onAssetsLoaded) {
            const originalOnAssetsLoaded = this.baseMap.onAssetsLoaded;
            this.baseMap.onAssetsLoaded = (assets) => {
                // Call original handler
                originalOnAssetsLoaded.call(this.baseMap, assets);
                
                // Apply division colors to markers
                this.applyDivisionColorsToMarkers(assets);
            };
        }
        
        // Monitor viewport for responsive adjustments
        this.setupResponsiveAdjustments();
        
        // Log initialization
        if (window.VisualDiagnostics) {
            window.VisualDiagnostics.logEvent('EnhancedMapUX', 'ux-initialized', {
                message: 'Enhanced Map UX initialized'
            });
        }
    }
    
    addLegendPanel() {
        // Create legend panel HTML
        const legendHTML = `
            <div id="map-legend" class="map-legend collapsed">
                <div class="legend-header">
                    <h6>Map Legend</h6>
                    <button class="legend-toggle-button">
                        <i class="bi bi-chevron-down"></i>
                    </button>
                </div>
                <div class="legend-content">
                    <div class="legend-section">
                        <h6>Division Colors</h6>
                        <div class="color-item">
                            <span class="color-swatch" style="background-color: #3366FF;"></span>
                            <span class="color-label">DFW (DIV 2)</span>
                        </div>
                        <div class="color-item">
                            <span class="color-swatch" style="background-color: #FF3333;"></span>
                            <span class="color-label">HOU (DIV 4)</span>
                        </div>
                        <div class="color-item">
                            <span class="color-swatch" style="background-color: #33CC33;"></span>
                            <span class="color-label">WT (DIV 3)</span>
                        </div>
                        <div class="color-item">
                            <span class="color-swatch" style="background-color: #FFCC00;"></span>
                            <span class="color-label">TEXDIST (DIV 8)</span>
                        </div>
                        <div class="color-item">
                            <span class="color-swatch" style="background-color: #999999;"></span>
                            <span class="color-label">Unassigned</span>
                        </div>
                    </div>
                    
                    <div class="legend-section">
                        <h6>Asset Types</h6>
                        <div class="icon-item">
                            <i class="bi bi-truck icon-swatch"></i>
                            <span class="icon-label">Truck</span>
                        </div>
                        <div class="icon-item">
                            <i class="bi bi-bullseye icon-swatch"></i>
                            <span class="icon-label">Heavy Equipment</span>
                        </div>
                        <div class="icon-item">
                            <i class="bi bi-cone-striped icon-swatch"></i>
                            <span class="icon-label">Safety Equipment</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Add legend panel to map
        const mapContainer = document.getElementById('map-container');
        if (mapContainer) {
            const legendDiv = document.createElement('div');
            legendDiv.innerHTML = legendHTML;
            mapContainer.appendChild(legendDiv.firstElementChild);
            
            // Add event listener for toggling legend
            const legendToggle = document.querySelector('.legend-toggle-button');
            if (legendToggle) {
                legendToggle.addEventListener('click', () => {
                    this.toggleLegend();
                });
            }
            
            // Add styles
            const style = document.createElement('style');
            style.textContent = `
                .map-legend {
                    position: absolute;
                    bottom: 20px;
                    right: 10px;
                    background: rgba(40, 40, 40, 0.85);
                    border-radius: 5px;
                    box-shadow: 0 1px 5px rgba(0, 0, 0, 0.3);
                    max-width: 300px;
                    width: calc(100% - 20px);
                    max-height: 80%;
                    z-index: 1000;
                    transition: all 0.3s ease;
                    overflow: hidden;
                    font-size: 13px;
                }
                
                .map-legend.collapsed {
                    max-height: 40px;
                }
                
                .legend-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 8px 12px;
                    background: rgba(30, 30, 30, 0.5);
                    cursor: pointer;
                }
                
                .legend-header h6 {
                    margin: 0;
                    font-size: 14px;
                    font-weight: 600;
                    color: #fff;
                }
                
                .legend-toggle-button {
                    background: none;
                    border: none;
                    color: #fff;
                    cursor: pointer;
                    padding: 0;
                    transition: transform 0.3s ease;
                }
                
                .map-legend.collapsed .legend-toggle-button i {
                    transform: rotate(180deg);
                }
                
                .legend-content {
                    padding: 10px;
                    overflow-y: auto;
                    max-height: calc(80vh - 40px);
                }
                
                .legend-section {
                    margin-bottom: 12px;
                }
                
                .legend-section h6 {
                    margin: 0 0 8px 0;
                    font-size: 13px;
                    font-weight: 500;
                    color: #ccc;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                    padding-bottom: 5px;
                }
                
                .color-item, .icon-item {
                    display: flex;
                    align-items: center;
                    margin-bottom: 5px;
                }
                
                .color-swatch {
                    width: 16px;
                    height: 16px;
                    border-radius: 3px;
                    margin-right: 8px;
                }
                
                .icon-swatch {
                    width: 16px;
                    height: 16px;
                    margin-right: 8px;
                    text-align: center;
                }
                
                .color-label, .icon-label {
                    font-size: 12px;
                    color: #ddd;
                }
                
                @media (max-width: 768px) {
                    .map-legend {
                        bottom: 10px;
                        max-width: calc(100% - 20px);
                    }
                    
                    .legend-content {
                        max-height: 50vh;
                    }
                }
            `;
            
            document.head.appendChild(style);
        }
    }
    
    makeFiltersStickyForDesktop() {
        // Find the sidebar filter container
        const sidebarContainer = document.querySelector('.map-sidebar');
        if (!sidebarContainer) return;
        
        // Create a sticky wrapper
        const stickyWrapper = document.createElement('div');
        stickyWrapper.className = 'sticky-sidebar-wrapper';
        
        // Move the sidebar into the sticky wrapper
        const parentElement = sidebarContainer.parentElement;
        parentElement.replaceChild(stickyWrapper, sidebarContainer);
        stickyWrapper.appendChild(sidebarContainer);
        
        // Add a toggle button
        const toggleButton = document.createElement('button');
        toggleButton.className = 'toggle-sidebar-button';
        toggleButton.innerHTML = '<i class="bi bi-layout-sidebar"></i>';
        toggleButton.title = 'Toggle Sticky Sidebar';
        stickyWrapper.appendChild(toggleButton);
        
        // Add event listener for toggle button
        toggleButton.addEventListener('click', () => {
            this.toggleStickySidebar();
        });
        
        // Add styles
        const style = document.createElement('style');
        style.textContent = `
            .sticky-sidebar-wrapper {
                position: relative;
            }
            
            .sticky-sidebar-wrapper.sticky {
                position: sticky;
                top: 10px;
                max-height: calc(100vh - 20px);
                overflow-y: auto;
                padding-right: 10px;
                z-index: 900;
            }
            
            .toggle-sidebar-button {
                position: absolute;
                top: 10px;
                right: 10px;
                background: rgba(30, 30, 30, 0.7);
                color: #fff;
                border: none;
                border-radius: 3px;
                width: 32px;
                height: 32px;
                display: flex;
                justify-content: center;
                align-items: center;
                cursor: pointer;
                z-index: 901;
            }
            
            @media (max-width: 768px) {
                .sticky-sidebar-wrapper.sticky {
                    position: relative;
                    top: 0;
                    max-height: none;
                    overflow-y: visible;
                    padding-right: 0;
                }
                
                .toggle-sidebar-button {
                    display: none;
                }
            }
        `;
        
        document.head.appendChild(style);
    }
    
    enhanceAssetPopups() {
        // Replace or enhance the popup template in the base map
        if (this.baseMap.createPopupContent) {
            const originalCreatePopupContent = this.baseMap.createPopupContent;
            
            this.baseMap.createPopupContent = (asset) => {
                // Get original content
                const originalContent = originalCreatePopupContent.call(this.baseMap, asset);
                
                // Create enhanced popup with job reassignment dropdown
                const division = this.getAssetDivision(asset);
                const divisionColor = this.divisionColors[division] || this.divisionColors.UNASSIGNED;
                
                // Find where the actions section would be
                const lastClosingDivIndex = originalContent.lastIndexOf('</div>');
                
                // Insert our enhanced actions section
                const enhancedContent = originalContent.substring(0, lastClosingDivIndex) + 
                    this.createEnhancedActions(asset) + 
                    originalContent.substring(lastClosingDivIndex);
                
                // Add division indicator
                return enhancedContent.replace(
                    '<div class="asset-info-header">',
                    `<div class="asset-info-header" style="border-left: 4px solid ${divisionColor};">`
                );
            };
            
            // Styles for enhanced popup
            const style = document.createElement('style');
            style.textContent = `
                .popup-actions {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 5px;
                    margin-top: 8px;
                    border-top: 1px solid rgba(255, 255, 255, 0.1);
                    padding-top: 8px;
                }
                
                .asset-action-button {
                    flex: 1;
                    min-width: 80px;
                    background: rgba(40, 40, 40, 0.7);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    border-radius: 3px;
                    color: #fff;
                    padding: 4px 8px;
                    font-size: 11px;
                    cursor: pointer;
                    text-align: center;
                    transition: background 0.2s ease;
                }
                
                .asset-action-button:hover {
                    background: rgba(60, 60, 60, 0.8);
                }
                
                .asset-action-button.primary {
                    background: rgba(51, 122, 183, 0.7);
                }
                
                .asset-action-button.primary:hover {
                    background: rgba(51, 122, 183, 0.8);
                }
                
                .job-selector {
                    width: 100%;
                    margin-top: 5px;
                    display: none;
                }
                
                .job-selector.visible {
                    display: block;
                }
                
                .selector-header {
                    font-size: 11px;
                    color: #ccc;
                    margin-bottom: 4px;
                }
                
                .job-select {
                    width: 100%;
                    background: rgba(30, 30, 30, 0.7);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    border-radius: 3px;
                    color: #fff;
                    padding: 4px;
                    font-size: 11px;
                }
                
                .confirm-cancel {
                    display: flex;
                    gap: 5px;
                    margin-top: 5px;
                }
                
                .confirm-button {
                    flex: 1;
                    background: rgba(40, 167, 69, 0.7);
                    border: none;
                    border-radius: 3px;
                    color: #fff;
                    padding: 4px;
                    font-size: 11px;
                    cursor: pointer;
                }
                
                .cancel-button {
                    flex: 1;
                    background: rgba(220, 53, 69, 0.7);
                    border: none;
                    border-radius: 3px;
                    color: #fff;
                    padding: 4px;
                    font-size: 11px;
                    cursor: pointer;
                }
                
                .asset-hover-card {
                    position: absolute;
                    padding: 8px 12px;
                    background: rgba(40, 40, 40, 0.9);
                    border-radius: 4px;
                    border-left: 3px solid #33D4FF;
                    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
                    font-size: 12px;
                    color: #fff;
                    z-index: 1000;
                    pointer-events: none;
                    transition: opacity 0.2s ease;
                    opacity: 0;
                    max-width: 250px;
                }
                
                .asset-hover-card.visible {
                    opacity: 1;
                }
                
                .hover-header {
                    font-weight: bold;
                    margin-bottom: 4px;
                }
                
                .hover-detail {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 2px;
                    font-size: 11px;
                }
                
                .hover-label {
                    color: #ccc;
                    margin-right: 8px;
                }
                
                .hover-value {
                    color: #fff;
                    font-weight: 500;
                }
            `;
            
            document.head.appendChild(style);
        }
    }
    
    createEnhancedActions(asset) {
        const assetId = asset.asset_id || asset.id;
        const jobNumber = this.extractJobNumber(asset.location);
        
        return `
            <div class="popup-actions">
                <button class="asset-action-button reassign-job-button primary" data-asset-id="${assetId}">
                    <i class="bi bi-arrow-repeat"></i> Reassign Job
                </button>
                <button class="asset-action-button mark-billable-button" data-asset-id="${assetId}">
                    <i class="bi bi-receipt"></i> Mark Billable
                </button>
                <button class="asset-action-button flag-review-button" data-asset-id="${assetId}">
                    <i class="bi bi-flag"></i> Flag for Review
                </button>
                
                <div class="job-selector" id="job-selector-${assetId}">
                    <div class="selector-header">Select New Job Site:</div>
                    <select class="job-select" id="job-select-${assetId}">
                        <option value="">-- Select Job --</option>
                        <option value="2023-032">2023-032 SH 345 Bridge Rehabilitation</option>
                        <option value="2024-019">2024-019 (15) Tarrant VA Bridge Rehab</option>
                        <option value="DFW-YARD">DFW Yard</option>
                        <option value="HOU-YARD">HOU Yard/Shop</option>
                        <option value="2023-007">2023-007 Ector BI 20E Rehab Roadway</option>
                        <option value="2024-012">2024-012 Dal IH635 U-Turn Bridge</option>
                        <option value="2024-004">2024-004 CoD Sidewalks 2024</option>
                    </select>
                    
                    <div class="confirm-cancel">
                        <button class="confirm-button" data-asset-id="${assetId}">Confirm</button>
                        <button class="cancel-button" data-asset-id="${assetId}">Cancel</button>
                    </div>
                </div>
            </div>
        `;
    }
    
    addHoverEffects() {
        // Create a hover card element
        const hoverCard = document.createElement('div');
        hoverCard.className = 'asset-hover-card';
        hoverCard.id = 'asset-hover-card';
        document.body.appendChild(hoverCard);
        
        // Track mouse position
        document.addEventListener('mousemove', (event) => {
            if (hoverCard.classList.contains('visible')) {
                // Position the hover card near cursor but not directly under it
                hoverCard.style.left = (event.clientX + 15) + 'px';
                hoverCard.style.top = (event.clientY + 15) + 'px';
                
                // Adjust if too close to right edge
                const cardRect = hoverCard.getBoundingClientRect();
                if (cardRect.right > window.innerWidth) {
                    hoverCard.style.left = (event.clientX - cardRect.width - 15) + 'px';
                }
                
                // Adjust if too close to bottom edge
                if (cardRect.bottom > window.innerHeight) {
                    hoverCard.style.top = (event.clientY - cardRect.height - 15) + 'px';
                }
            }
        });
        
        // Add hover behavior to asset markers
        if (this.baseMap.onAssetMarkerCreated) {
            const originalOnMarkerCreated = this.baseMap.onAssetMarkerCreated;
            
            this.baseMap.onAssetMarkerCreated = (marker, asset) => {
                // Call original handler
                originalOnMarkerCreated.call(this.baseMap, marker, asset);
                
                // Add mouseover behavior
                marker.on('mouseover', (event) => {
                    // Don't show hover on mobile
                    if (this.isMobileDevice()) return;
                    
                    // Update hover card content
                    this.updateHoverCard(asset);
                    
                    // Show hover card
                    hoverCard.classList.add('visible');
                });
                
                // Add mouseout behavior
                marker.on('mouseout', () => {
                    hoverCard.classList.remove('visible');
                });
            };
        }
    }
    
    updateHoverCard(asset) {
        const hoverCard = document.getElementById('asset-hover-card');
        if (!hoverCard) return;
        
        const assetId = asset.asset_id || asset.id;
        const division = this.getAssetDivision(asset);
        const divisionColor = this.divisionColors[division] || this.divisionColors.UNASSIGNED;
        const jobNumber = this.extractJobNumber(asset.location);
        const driver = asset.driver || 'Unassigned';
        const lastUpdate = asset.last_update || 'Unknown';
        
        // Update hover card style and content
        hoverCard.style.borderColor = divisionColor;
        
        hoverCard.innerHTML = `
            <div class="hover-header">${assetId} ${asset.make} ${asset.model}</div>
            <div class="hover-detail">
                <span class="hover-label">Driver:</span>
                <span class="hover-value">${driver}</span>
            </div>
            <div class="hover-detail">
                <span class="hover-label">Job:</span>
                <span class="hover-value">${jobNumber || 'Unassigned'}</span>
            </div>
            <div class="hover-detail">
                <span class="hover-label">Division:</span>
                <span class="hover-value">${division}</span>
            </div>
            <div class="hover-detail">
                <span class="hover-label">Last Update:</span>
                <span class="hover-value">${lastUpdate}</span>
            </div>
        `;
    }
    
    setupResponsiveAdjustments() {
        // Set initial state based on viewport
        this.adjustForViewport();
        
        // Update on resize
        window.addEventListener('resize', () => {
            this.adjustForViewport();
        });
    }
    
    adjustForViewport() {
        // Check if mobile device
        const isMobile = this.isMobileDevice();
        
        // Adjust UI elements based on viewport
        const legendPanel = document.getElementById('map-legend');
        if (legendPanel) {
            if (isMobile) {
                legendPanel.classList.add('collapsed');
            }
        }
        
        const stickyWrapper = document.querySelector('.sticky-sidebar-wrapper');
        if (stickyWrapper) {
            if (isMobile) {
                stickyWrapper.classList.remove('sticky');
            } else if (!stickyWrapper.classList.contains('sticky')) {
                // Enable sticky by default on desktop
                stickyWrapper.classList.add('sticky');
            }
        }
    }
    
    isMobileDevice() {
        return window.innerWidth < 768;
    }
    
    toggleLegend(visible) {
        const legendPanel = document.getElementById('map-legend');
        if (!legendPanel) return;
        
        if (visible !== undefined) {
            if (visible) {
                legendPanel.classList.remove('collapsed');
            } else {
                legendPanel.classList.add('collapsed');
            }
        } else {
            legendPanel.classList.toggle('collapsed');
        }
        
        // Log to event timeline
        if (window.VisualDiagnostics) {
            const isVisible = !legendPanel.classList.contains('collapsed');
            window.VisualDiagnostics.logEvent('EnhancedMapUX', 'legend-toggled', {
                visible: isVisible,
                message: `Map legend ${isVisible ? 'shown' : 'hidden'}`
            });
        }
        
        return {
            status: 'legend-toggled',
            visible: !legendPanel.classList.contains('collapsed')
        };
    }
    
    toggleStickySidebar(enabled) {
        const stickyWrapper = document.querySelector('.sticky-sidebar-wrapper');
        if (!stickyWrapper) return;
        
        if (enabled !== undefined) {
            if (enabled) {
                stickyWrapper.classList.add('sticky');
            } else {
                stickyWrapper.classList.remove('sticky');
            }
        } else {
            stickyWrapper.classList.toggle('sticky');
        }
        
        // Log to event timeline
        if (window.VisualDiagnostics) {
            const isSticky = stickyWrapper.classList.contains('sticky');
            window.VisualDiagnostics.logEvent('EnhancedMapUX', 'sidebar-toggled', {
                sticky: isSticky,
                message: `Sidebar sticky mode ${isSticky ? 'enabled' : 'disabled'}`
            });
        }
        
        return {
            status: 'sidebar-toggled',
            sticky: stickyWrapper.classList.contains('sticky')
        };
    }
    
    showJobReassignDialog(assetId) {
        const selector = document.getElementById(`job-selector-${assetId}`);
        if (!selector) return;
        
        selector.classList.add('visible');
        
        // Attach event listeners if not already attached
        const confirmBtn = selector.querySelector('.confirm-button');
        const cancelBtn = selector.querySelector('.cancel-button');
        
        if (confirmBtn && !confirmBtn.hasClickListener) {
            confirmBtn.hasClickListener = true;
            confirmBtn.addEventListener('click', () => {
                const jobSelect = document.getElementById(`job-select-${assetId}`);
                const newJobNumber = jobSelect.value;
                
                if (newJobNumber) {
                    this.quickReassignJob(assetId, newJobNumber);
                }
                
                selector.classList.remove('visible');
            });
        }
        
        if (cancelBtn && !cancelBtn.hasClickListener) {
            cancelBtn.hasClickListener = true;
            cancelBtn.addEventListener('click', () => {
                selector.classList.remove('visible');
            });
        }
        
        return {
            status: 'job-selector-shown',
            assetId: assetId
        };
    }
    
    quickReassignJob(assetId, jobNumber) {
        console.log(`[PASSIVE] Would reassign asset ${assetId} to job ${jobNumber}`);
        
        // Show confirmation message
        const selector = document.getElementById(`job-selector-${assetId}`);
        if (selector) {
            selector.classList.remove('visible');
        }
        
        // Find popup and update it
        const popupContent = document.querySelector(`.leaflet-popup-content`);
        if (popupContent) {
            const confirmationDiv = document.createElement('div');
            confirmationDiv.className = 'status-confirmation';
            confirmationDiv.innerHTML = `
                <div class="status-message success">
                    <i class="bi bi-check-circle"></i> Assignment request logged (passive mode)
                </div>
            `;
            popupContent.appendChild(confirmationDiv);
            
            // Add confirmation styles
            const style = document.createElement('style');
            style.textContent = `
                .status-confirmation {
                    margin-top: 8px;
                    width: 100%;
                }
                
                .status-message {
                    padding: 6px 8px;
                    border-radius: 3px;
                    font-size: 12px;
                    text-align: center;
                }
                
                .status-message.success {
                    background: rgba(40, 167, 69, 0.2);
                    border: 1px solid rgba(40, 167, 69, 0.4);
                    color: #2ecc71;
                }
                
                .status-message i {
                    margin-right: 5px;
                }
            `;
            
            document.head.appendChild(style);
            
            // Remove after a few seconds
            setTimeout(() => {
                if (confirmationDiv.parentNode) {
                    confirmationDiv.parentNode.removeChild(confirmationDiv);
                }
            }, 4000);
        }
        
        // Log to event timeline
        if (window.VisualDiagnostics) {
            window.VisualDiagnostics.logEvent('EnhancedMapUX', 'passive-job-reassignment', {
                assetId: assetId,
                jobNumber: jobNumber,
                message: `[PASSIVE] Asset ${assetId} would be reassigned to job ${jobNumber}`
            });
            
            // Register conflict for passive mode
            window.VisualDiagnostics.registerConflict(
                'passive-job-reassignment',
                { assetId: assetId, jobNumber: jobNumber },
                { 
                    message: `Assignment of asset ${assetId} to job ${jobNumber} requested but not executed (passive mode)`,
                    severity: 'info',
                    recommendedAction: 'Set MapAgent to active mode to enable assignments'
                }
            );
        }
        
        return {
            status: 'passive-reassign-job',
            assetId: assetId,
            jobNumber: jobNumber
        };
    }
    
    applyDivisionColorsToMarkers(assets) {
        // This function applies division-based colors to asset markers
        for (const asset of assets) {
            const assetId = asset.asset_id || asset.id;
            const division = this.getAssetDivision(asset);
            const divisionColor = this.divisionColors[division] || this.divisionColors.UNASSIGNED;
            
            // Find marker for this asset
            if (this.baseMap.markers && this.baseMap.markers[assetId]) {
                const marker = this.baseMap.markers[assetId];
                
                // Update marker icon color
                if (marker.setIcon) {
                    // Get icon options and update color
                    const iconOptions = this.getColoredIconOptions(asset, divisionColor);
                    const newIcon = L.divIcon(iconOptions);
                    marker.setIcon(newIcon);
                }
            }
        }
    }
    
    getColoredIconOptions(asset, color) {
        // Get asset type to determine icon
        const assetType = asset.type?.toLowerCase() || '';
        let iconClass = 'bi-bullseye'; // Default
        
        // Determine icon based on asset type
        if (assetType.includes('truck')) {
            iconClass = 'bi-truck';
        } else if (assetType.includes('sweeper') || assetType.includes('tma')) {
            iconClass = 'bi-cone-striped';
        } else if (assetType.includes('excavator') || assetType.includes('loader')) {
            iconClass = 'bi-wrench';
        } else if (assetType.includes('crane')) {
            iconClass = 'bi-minecart-loaded';
        }
        
        // Create icon options with color
        return {
            html: `<div class="asset-marker" style="background-color: ${color}"><i class="bi ${iconClass}"></i></div>`,
            className: 'asset-marker-container',
            iconSize: [30, 30]
        };
    }
    
    getAssetDivision(asset) {
        // Determine division from job number in location
        const jobNumber = this.extractJobNumber(asset.location);
        
        if (jobNumber) {
            return this.jobToDivision[jobNumber] || 'UNASSIGNED';
        }
        
        // If no job number, use division naming patterns in location name
        const location = asset.location?.toUpperCase() || '';
        
        if (location.includes('DFW') || location.includes('DALLAS') || location.includes('TARRANT')) {
            return 'DIV 2';
        } else if (location.includes('HOU') || location.includes('HOUSTON')) {
            return 'DIV 4';
        } else if (location.includes('ODESSA') || location.includes('ECTOR') || location.includes('MIDLAND')) {
            return 'DIV 3';
        } else if (location.includes('TEX')) {
            return 'DIV 8';
        }
        
        return 'UNASSIGNED';
    }
    
    extractJobNumber(location = '') {
        // Extract job number from location string
        // Look for common patterns like 2023-032, DFW-YARD, etc.
        const jobMatch = location.match(/(\d{4}-\d{3}|\w+-YARD)/i);
        if (jobMatch) {
            return jobMatch[1];
        }
        return null;
    }
    
    enhanceAssetMarker(assetId, options) {
        // Enhance specific asset marker with options
        if (!this.baseMap.markers || !this.baseMap.markers[assetId]) {
            return { status: 'error', message: 'Asset marker not found' };
        }
        
        const marker = this.baseMap.markers[assetId];
        
        // Apply options
        if (options.color) {
            // Get asset from base map
            const asset = this.baseMap.assets?.find(a => (a.asset_id || a.id) === assetId);
            if (asset) {
                const iconOptions = this.getColoredIconOptions(asset, options.color);
                const newIcon = L.divIcon(iconOptions);
                marker.setIcon(newIcon);
            }
        }
        
        if (options.pulsate) {
            // Add pulsating effect to marker
            const markerElement = marker.getElement();
            if (markerElement) {
                markerElement.classList.add('pulsating-marker');
                
                // Add pulsating style if not already added
                if (!document.getElementById('pulsating-marker-style')) {
                    const style = document.createElement('style');
                    style.id = 'pulsating-marker-style';
                    style.textContent = `
                        @keyframes pulse {
                            0% { transform: scale(1); opacity: 1; }
                            50% { transform: scale(1.2); opacity: 0.8; }
                            100% { transform: scale(1); opacity: 1; }
                        }
                        
                        .pulsating-marker .asset-marker {
                            animation: pulse 1s infinite;
                        }
                    `;
                    document.head.appendChild(style);
                }
            }
        }
        
        // Log to event timeline
        if (window.VisualDiagnostics) {
            window.VisualDiagnostics.logEvent('EnhancedMapUX', 'asset-marker-enhanced', {
                assetId: assetId,
                options: options,
                message: `Asset marker ${assetId} enhanced with custom styling`
            });
        }
        
        return {
            status: 'asset-marker-enhanced',
            assetId: assetId
        };
    }
}

// Wait for GENIUS CORE and EnhancedMap to be available
document.addEventListener('DOMContentLoaded', function() {
    // Check if prerequisites are loaded every 100ms
    const checkPrerequisites = setInterval(() => {
        if (window.GeniusCore && window.EnhancedMap) {
            clearInterval(checkPrerequisites);
            window.MapUX = new EnhancedMapUX();
            console.log('Enhanced Map UX connected to GENIUS CORE');
        }
    }, 100);
});

console.log('GENIUS CORE Enhanced Map UX Loaded');
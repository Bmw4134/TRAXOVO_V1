/**
 * TRAXORA GENIUS CORE | Visual Diagnostics System
 * 
 * This module enhances the GENIUS CORE with visual diagnostic overlays,
 * conflict resolution interfaces, and advanced telemetry score visualization.
 */

class VisualDiagnosticsSystem {
    constructor() {
        // Check if required components exist
        if (!window.GeniusCore) {
            console.error('GENIUS CORE not available. Visual Diagnostics initialization aborted.');
            return;
        }
        
        this.geniusCore = window.GeniusCore;
        this.eventTimeline = [];
        this.conflicts = [];
        this.overrides = {};
        
        // Register with GENIUS CORE
        this.diagnosticsAgent = {
            id: 'VisualDiagnostics',
            
            handleMessage(message) {
                switch (message.type) {
                    case 'log-event':
                        return window.VisualDiagnostics.logEvent(
                            message.payload.moduleId,
                            message.payload.eventType,
                            message.payload.details
                        );
                        
                    case 'register-conflict':
                        return window.VisualDiagnostics.registerConflict(
                            message.payload.conflictType,
                            message.payload.entities,
                            message.payload.details
                        );
                        
                    case 'get-event-timeline':
                        return {
                            status: 'event-timeline',
                            timeline: window.VisualDiagnostics.getEventTimeline(
                                message.payload.limit,
                                message.payload.filter
                            )
                        };
                        
                    case 'set-override':
                        return window.VisualDiagnostics.setOverride(
                            message.payload.entityType,
                            message.payload.entityId,
                            message.payload.reason,
                            message.payload.expirationTime
                        );
                        
                    case 'remove-override':
                        return window.VisualDiagnostics.removeOverride(
                            message.payload.entityType,
                            message.payload.entityId
                        );
                        
                    case 'get-telemetry-score':
                        return {
                            status: 'telemetry-score',
                            score: window.VisualDiagnostics.getTelemetryScore(
                                message.payload.assetId,
                                message.payload.jobNumber
                            )
                        };
                        
                    default:
                        return { status: 'unknown-message-type' };
                }
            }
        };
        
        this.geniusCore.registerAgent('VisualDiagnostics', this.diagnosticsAgent);
        
        // Initialize diagnostics components
        this.initializeComponents();
        
        console.log('Visual Diagnostics System initialized');
    }
    
    initializeComponents() {
        // Create diagnostic overlay container if it doesn't exist
        let diagnosticContainer = document.getElementById('genius-diagnostic-container');
        if (!diagnosticContainer) {
            diagnosticContainer = document.createElement('div');
            diagnosticContainer.id = 'genius-diagnostic-container';
            diagnosticContainer.className = 'genius-diagnostic-container';
            document.body.appendChild(diagnosticContainer);
            
            // Add styles
            const style = document.createElement('style');
            style.textContent = `
                .genius-diagnostic-container {
                    position: fixed;
                    z-index: 1001;
                    pointer-events: none;
                }
                
                .conflict-overlay {
                    position: absolute;
                    background-color: rgba(255, 0, 0, 0.2);
                    border: 2px dashed #ff0000;
                    pointer-events: none;
                    z-index: 1000;
                }
                
                .genius-popup {
                    position: absolute;
                    background: rgba(33, 37, 41, 0.9);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    border-radius: 8px;
                    color: white;
                    font-family: sans-serif;
                    z-index: 1002;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
                    padding: 15px;
                    max-width: 400px;
                    pointer-events: auto;
                }
                
                .genius-popup-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 10px;
                    padding-bottom: 5px;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                }
                
                .genius-popup-title {
                    margin: 0;
                    color: #33d4ff;
                    font-size: 16px;
                    font-weight: bold;
                }
                
                .genius-popup-close {
                    background: none;
                    border: none;
                    color: white;
                    font-size: 18px;
                    cursor: pointer;
                }
                
                .telemetry-score {
                    display: flex;
                    flex-direction: column;
                    gap: 8px;
                }
                
                .score-item {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .score-label {
                    font-weight: bold;
                }
                
                .score-value {
                    display: flex;
                    align-items: center;
                    gap: 5px;
                }
                
                .score-bar {
                    width: 100px;
                    height: 8px;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 4px;
                    overflow: hidden;
                }
                
                .score-fill {
                    height: 100%;
                    transition: width 0.3s ease;
                }
                
                .score-fill.high {
                    background: #28a745;
                }
                
                .score-fill.medium {
                    background: #ffc107;
                }
                
                .score-fill.low {
                    background: #dc3545;
                }
                
                .score-percentage {
                    font-size: 12px;
                    color: #ccc;
                }
                
                .event-timeline {
                    position: fixed;
                    bottom: 300px;
                    right: 20px;
                    width: 300px;
                    max-height: 400px;
                    overflow-y: auto;
                    background: rgba(33, 37, 41, 0.9);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    border-radius: 8px;
                    color: white;
                    font-family: sans-serif;
                    z-index: 1000;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                    pointer-events: auto;
                    display: none;
                }
                
                .event-timeline.visible {
                    display: block;
                }
                
                .event-timeline-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 10px 15px;
                    background: rgba(0, 0, 0, 0.2);
                    cursor: pointer;
                }
                
                .event-timeline-header h6 {
                    margin: 0;
                    color: #33d4ff;
                }
                
                .event-timeline-toggle {
                    background: none;
                    border: none;
                    color: white;
                    font-size: 16px;
                    cursor: pointer;
                    padding: 0 5px;
                }
                
                .event-timeline-content {
                    padding: 10px;
                    display: flex;
                    flex-direction: column;
                    gap: 5px;
                }
                
                .timeline-event {
                    padding: 8px;
                    border-radius: 4px;
                    background: rgba(255, 255, 255, 0.1);
                    font-size: 12px;
                }
                
                .timeline-event-header {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 3px;
                }
                
                .event-module {
                    font-weight: bold;
                }
                
                .event-time {
                    color: #ccc;
                }
                
                .event-type {
                    font-style: italic;
                    color: #33d4ff;
                }
                
                .event-details {
                    color: #ccc;
                    margin-top: 3px;
                }
                
                .override-panel {
                    position: fixed;
                    right: 20px;
                    bottom: 350px;
                    width: 300px;
                    background: rgba(33, 37, 41, 0.9);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    border-radius: 8px;
                    color: white;
                    font-family: sans-serif;
                    z-index: 1000;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                    pointer-events: auto;
                    display: none;
                }
                
                .override-panel.visible {
                    display: block;
                }
                
                .override-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 10px 15px;
                    background: rgba(0, 0, 0, 0.2);
                    cursor: pointer;
                }
                
                .override-header h6 {
                    margin: 0;
                    color: #33d4ff;
                }
                
                .override-toggle {
                    background: none;
                    border: none;
                    color: white;
                    font-size: 16px;
                    cursor: pointer;
                    padding: 0 5px;
                }
                
                .override-content {
                    padding: 15px;
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                }
                
                .override-form {
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                }
                
                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 5px;
                }
                
                .form-group label {
                    font-weight: bold;
                    font-size: 12px;
                }
                
                .form-group select,
                .form-group input,
                .form-group textarea {
                    background: #444;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    padding: 8px;
                }
                
                .override-actions {
                    display: flex;
                    gap: 10px;
                    margin-top: 10px;
                }
                
                .override-actions button {
                    flex: 1;
                    padding: 8px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-weight: bold;
                }
                
                .override-actions button.primary {
                    background: #33d4ff;
                    color: #111;
                }
                
                .override-actions button.secondary {
                    background: #444;
                    color: white;
                }
                
                .active-overrides {
                    margin-top: 15px;
                    border-top: 1px solid rgba(255, 255, 255, 0.1);
                    padding-top: 15px;
                }
                
                .active-overrides h6 {
                    margin: 0 0 10px 0;
                    font-size: 14px;
                }
                
                .override-item {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 8px;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 4px;
                    margin-bottom: 5px;
                }
                
                .override-item-details {
                    font-size: 12px;
                }
                
                .override-item-remove {
                    background: none;
                    border: none;
                    color: #dc3545;
                    cursor: pointer;
                    font-size: 16px;
                }
            `;
            
            document.head.appendChild(style);
        }
        
        // Create event timeline
        this.createEventTimeline();
        
        // Create override panel
        this.createOverridePanel();
        
        // Setup periodic refresh
        setInterval(() => this.refreshDiagnostics(), 5000);
    }
    
    createEventTimeline() {
        let timelinePanel = document.getElementById('event-timeline');
        if (!timelinePanel) {
            timelinePanel = document.createElement('div');
            timelinePanel.id = 'event-timeline';
            timelinePanel.className = 'event-timeline';
            
            timelinePanel.innerHTML = `
                <div class="event-timeline-header">
                    <h6>GENIUS CORE Event Timeline</h6>
                    <button class="event-timeline-toggle">−</button>
                </div>
                <div class="event-timeline-content" id="timeline-events">
                    <div class="timeline-event">
                        <div class="timeline-event-header">
                            <span class="event-module">VisualDiagnostics</span>
                            <span class="event-time">Now</span>
                        </div>
                        <div class="event-type">System Initialized</div>
                        <div class="event-details">Visual Diagnostics System is now active</div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(timelinePanel);
            
            // Add toggle behavior
            const header = timelinePanel.querySelector('.event-timeline-header');
            const toggleBtn = timelinePanel.querySelector('.event-timeline-toggle');
            
            header.addEventListener('click', function() {
                timelinePanel.classList.toggle('collapsed');
                toggleBtn.textContent = timelinePanel.classList.contains('collapsed') ? '+' : '−';
            });
            
            // Add toggle button to status panel
            const statusPanel = document.getElementById('genius-module-status');
            if (statusPanel) {
                const timelineToggle = document.createElement('button');
                timelineToggle.id = 'timeline-toggle-btn';
                timelineToggle.className = 'genius-button secondary small';
                timelineToggle.textContent = 'Timeline';
                timelineToggle.style.marginTop = '10px';
                
                timelineToggle.addEventListener('click', function() {
                    timelinePanel.classList.toggle('visible');
                });
                
                statusPanel.querySelector('.genius-ui-content').appendChild(timelineToggle);
            }
        }
        
        // Log initial event
        this.logEvent('VisualDiagnostics', 'system-initialization', {
            message: 'Timeline tracking system initialized'
        });
    }
    
    createOverridePanel() {
        let overridePanel = document.getElementById('override-panel');
        if (!overridePanel) {
            overridePanel = document.createElement('div');
            overridePanel.id = 'override-panel';
            overridePanel.className = 'override-panel';
            
            overridePanel.innerHTML = `
                <div class="override-header">
                    <h6>Manual Override Panel</h6>
                    <button class="override-toggle">−</button>
                </div>
                <div class="override-content">
                    <div class="override-form">
                        <div class="form-group">
                            <label for="override-entity-type">Entity Type</label>
                            <select id="override-entity-type">
                                <option value="job">Job Number</option>
                                <option value="asset">Asset</option>
                                <option value="driver">Driver</option>
                                <option value="pm">PM Code</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="override-entity-id">Entity ID</label>
                            <input type="text" id="override-entity-id" placeholder="e.g., 2023-032, EX-30, etc.">
                        </div>
                        <div class="form-group">
                            <label for="override-reason">Reason</label>
                            <textarea id="override-reason" placeholder="Why is this override needed?"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="override-expiration">Expiration</label>
                            <select id="override-expiration">
                                <option value="1h">1 hour</option>
                                <option value="8h">8 hours</option>
                                <option value="1d">1 day</option>
                                <option value="1w">1 week</option>
                                <option value="permanent">Permanent</option>
                            </select>
                        </div>
                        <div class="override-actions">
                            <button id="add-override-btn" class="primary">Add Override</button>
                            <button id="cancel-override-btn" class="secondary">Cancel</button>
                        </div>
                    </div>
                    <div class="active-overrides">
                        <h6>Active Overrides</h6>
                        <div id="active-overrides-list">
                            <!-- Dynamic content here -->
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(overridePanel);
            
            // Add toggle behavior
            const header = overridePanel.querySelector('.override-header');
            const toggleBtn = overridePanel.querySelector('.override-toggle');
            
            header.addEventListener('click', function() {
                overridePanel.classList.toggle('collapsed');
                toggleBtn.textContent = overridePanel.classList.contains('collapsed') ? '+' : '−';
            });
            
            // Add form behavior
            const addBtn = overridePanel.querySelector('#add-override-btn');
            const cancelBtn = overridePanel.querySelector('#cancel-override-btn');
            
            addBtn.addEventListener('click', () => {
                const entityType = document.getElementById('override-entity-type').value;
                const entityId = document.getElementById('override-entity-id').value;
                const reason = document.getElementById('override-reason').value;
                const expiration = document.getElementById('override-expiration').value;
                
                if (!entityId) {
                    alert('Entity ID is required');
                    return;
                }
                
                if (!reason) {
                    alert('Reason is required');
                    return;
                }
                
                let expirationTime = null;
                if (expiration !== 'permanent') {
                    const now = new Date();
                    switch (expiration) {
                        case '1h':
                            expirationTime = new Date(now.getTime() + 60 * 60 * 1000);
                            break;
                        case '8h':
                            expirationTime = new Date(now.getTime() + 8 * 60 * 60 * 1000);
                            break;
                        case '1d':
                            expirationTime = new Date(now.getTime() + 24 * 60 * 60 * 1000);
                            break;
                        case '1w':
                            expirationTime = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
                            break;
                    }
                }
                
                this.setOverride(entityType, entityId, reason, expirationTime);
                
                // Clear form
                document.getElementById('override-entity-id').value = '';
                document.getElementById('override-reason').value = '';
            });
            
            cancelBtn.addEventListener('click', () => {
                // Clear form
                document.getElementById('override-entity-id').value = '';
                document.getElementById('override-reason').value = '';
                overridePanel.classList.remove('visible');
            });
            
            // Add toggle button to status panel
            const statusPanel = document.getElementById('genius-module-status');
            if (statusPanel) {
                const overrideToggle = document.createElement('button');
                overrideToggle.id = 'override-toggle-btn';
                overrideToggle.className = 'genius-button secondary small';
                overrideToggle.textContent = 'Overrides';
                overrideToggle.style.marginTop = '10px';
                overrideToggle.style.marginLeft = '10px';
                
                overrideToggle.addEventListener('click', function() {
                    overridePanel.classList.toggle('visible');
                });
                
                statusPanel.querySelector('.genius-ui-content').appendChild(overrideToggle);
            }
        }
    }
    
    logEvent(moduleId, eventType, details) {
        const event = {
            moduleId: moduleId,
            eventType: eventType,
            details: details,
            timestamp: new Date().toISOString()
        };
        
        // Add to timeline
        this.eventTimeline.unshift(event);
        
        // Limit timeline size
        if (this.eventTimeline.length > 100) {
            this.eventTimeline.pop();
        }
        
        // Update UI if available
        this.updateEventTimelineUI();
        
        console.log(`Event logged: ${moduleId} - ${eventType}`);
        
        return {
            status: 'event-logged',
            event: event
        };
    }
    
    getEventTimeline(limit = 20, filter = null) {
        let timeline = this.eventTimeline;
        
        if (filter) {
            if (filter.moduleId) {
                timeline = timeline.filter(event => event.moduleId === filter.moduleId);
            }
            
            if (filter.eventType) {
                timeline = timeline.filter(event => event.eventType === filter.eventType);
            }
            
            if (filter.startTime) {
                const startTime = new Date(filter.startTime);
                timeline = timeline.filter(event => new Date(event.timestamp) >= startTime);
            }
            
            if (filter.endTime) {
                const endTime = new Date(filter.endTime);
                timeline = timeline.filter(event => new Date(event.timestamp) <= endTime);
            }
        }
        
        return timeline.slice(0, limit);
    }
    
    updateEventTimelineUI() {
        const timelineEvents = document.getElementById('timeline-events');
        if (!timelineEvents) return;
        
        // Get recent events
        const events = this.getEventTimeline(10);
        
        // Build HTML
        let html = '';
        events.forEach(event => {
            const date = new Date(event.timestamp);
            const timeString = date.toLocaleTimeString();
            
            html += `
                <div class="timeline-event">
                    <div class="timeline-event-header">
                        <span class="event-module">${event.moduleId}</span>
                        <span class="event-time">${timeString}</span>
                    </div>
                    <div class="event-type">${event.eventType}</div>
                    ${event.details && event.details.message ? 
                        `<div class="event-details">${event.details.message}</div>` : ''}
                </div>
            `;
        });
        
        timelineEvents.innerHTML = html;
    }
    
    registerConflict(conflictType, entities, details) {
        const conflict = {
            id: `conflict-${Date.now()}`,
            type: conflictType,
            entities: entities,
            details: details,
            timestamp: new Date().toISOString(),
            resolved: false
        };
        
        // Add to conflicts
        this.conflicts.push(conflict);
        
        // Log event
        this.logEvent('VisualDiagnostics', 'conflict-detected', {
            conflictType: conflictType,
            entities: entities,
            message: details.message || 'Conflict detected'
        });
        
        // Update UI if available
        this.showConflictOverlay(conflict);
        
        console.log(`Conflict registered: ${conflictType}`);
        
        return {
            status: 'conflict-registered',
            conflict: conflict
        };
    }
    
    showConflictOverlay(conflict) {
        // This would typically add visual indicators to the map or other UI components
        // For demonstration, we'll just log to console
        console.log('Conflict would show visual overlay:', conflict);
        
        // If this is a job site conflict, add a map overlay
        if (conflict.type === 'job-site-conflict' && conflict.entities.jobSite) {
            const jobSiteId = conflict.entities.jobSite;
            // This would add a red overlay to the job site on the map
            // Code would depend on how job sites are represented in the UI
        }
        
        // If this is an asset conflict, highlight the asset
        if (conflict.type === 'asset-conflict' && conflict.entities.assetId) {
            const assetId = conflict.entities.assetId;
            // This would highlight the asset on the map
            // Code would depend on how assets are represented in the UI
        }
        
        // If this is a driver conflict, show in driver module
        if (conflict.type === 'driver-conflict' && conflict.entities.driverId) {
            const driverId = conflict.entities.driverId;
            // This would highlight the driver in the driver module
            // Code would depend on how drivers are represented in the UI
        }
    }
    
    setOverride(entityType, entityId, reason, expirationTime) {
        const override = {
            id: `override-${Date.now()}`,
            entityType: entityType,
            entityId: entityId,
            reason: reason,
            createdAt: new Date().toISOString(),
            expirationTime: expirationTime ? expirationTime.toISOString() : null
        };
        
        // Store override
        if (!this.overrides[entityType]) {
            this.overrides[entityType] = {};
        }
        
        this.overrides[entityType][entityId] = override;
        
        // Log event
        this.logEvent('VisualDiagnostics', 'override-set', {
            entityType: entityType,
            entityId: entityId,
            message: `Manual override set for ${entityType} ${entityId}`
        });
        
        // Update UI
        this.updateOverridesUI();
        
        console.log(`Override set for ${entityType} ${entityId}`);
        
        return {
            status: 'override-set',
            override: override
        };
    }
    
    removeOverride(entityType, entityId) {
        if (!this.overrides[entityType] || !this.overrides[entityType][entityId]) {
            return {
                status: 'error',
                message: `No override found for ${entityType} ${entityId}`
            };
        }
        
        // Remove override
        delete this.overrides[entityType][entityId];
        
        // Log event
        this.logEvent('VisualDiagnostics', 'override-removed', {
            entityType: entityType,
            entityId: entityId,
            message: `Manual override removed for ${entityType} ${entityId}`
        });
        
        // Update UI
        this.updateOverridesUI();
        
        console.log(`Override removed for ${entityType} ${entityId}`);
        
        return {
            status: 'override-removed',
            entityType: entityType,
            entityId: entityId
        };
    }
    
    updateOverridesUI() {
        const overridesList = document.getElementById('active-overrides-list');
        if (!overridesList) return;
        
        // Build HTML
        let html = '';
        
        // Flatten overrides for display
        const flatOverrides = [];
        Object.keys(this.overrides).forEach(entityType => {
            Object.keys(this.overrides[entityType]).forEach(entityId => {
                flatOverrides.push(this.overrides[entityType][entityId]);
            });
        });
        
        if (flatOverrides.length === 0) {
            html = '<div class="empty-message">No active overrides</div>';
        } else {
            flatOverrides.forEach(override => {
                const expirationText = override.expirationTime ? 
                    `Expires: ${new Date(override.expirationTime).toLocaleString()}` : 
                    'Permanent';
                
                html += `
                    <div class="override-item" data-id="${override.id}">
                        <div class="override-item-details">
                            <strong>${override.entityType}: ${override.entityId}</strong><br>
                            <small>${expirationText}</small>
                        </div>
                        <button class="override-item-remove" data-type="${override.entityType}" data-id="${override.entityId}">&times;</button>
                    </div>
                `;
            });
        }
        
        overridesList.innerHTML = html;
        
        // Add remove button handlers
        const removeButtons = overridesList.querySelectorAll('.override-item-remove');
        removeButtons.forEach(button => {
            button.addEventListener('click', () => {
                const entityType = button.getAttribute('data-type');
                const entityId = button.getAttribute('data-id');
                this.removeOverride(entityType, entityId);
            });
        });
    }
    
    getTelemetryScore(assetId, jobNumber) {
        // In a real implementation, this would calculate real telemetry scores
        // For demonstration, we'll generate a somewhat random but meaningful score
        
        // Build a score with various factors
        const distanceScore = Math.floor(Math.random() * 40) + 60; // 60-100
        const timeAtJobScore = Math.floor(Math.random() * 50) + 50; // 50-100
        const historicalPatternScore = Math.floor(Math.random() * 30) + 70; // 70-100
        const driverMatchScore = Math.floor(Math.random() * 60) + 40; // 40-100
        
        // Weight the factors
        const weightedDistance = distanceScore * 0.35; // 35% weight
        const weightedTime = timeAtJobScore * 0.25; // 25% weight
        const weightedHistory = historicalPatternScore * 0.20; // 20% weight
        const weightedDriver = driverMatchScore * 0.20; // 20% weight
        
        // Calculate overall score
        const overallScore = Math.round(
            weightedDistance + 
            weightedTime + 
            weightedHistory + 
            weightedDriver
        );
        
        const result = {
            assetId: assetId,
            jobNumber: jobNumber,
            overallScore: overallScore,
            factors: {
                distance: distanceScore,
                timeAtJob: timeAtJobScore,
                historicalPattern: historicalPatternScore,
                driverMatch: driverMatchScore
            },
            confidenceLevel: overallScore >= 90 ? 'High' : overallScore >= 75 ? 'Medium' : 'Low',
            analysisTime: new Date().toISOString()
        };
        
        return result;
    }
    
    showTelemetryScorePopup(assetId, jobNumber, event) {
        // Calculate telemetry score
        const score = this.getTelemetryScore(assetId, jobNumber);
        
        // Create popup
        let popup = document.getElementById('telemetry-score-popup');
        if (!popup) {
            popup = document.createElement('div');
            popup.id = 'telemetry-score-popup';
            popup.className = 'genius-popup';
            document.body.appendChild(popup);
        }
        
        // Position popup near the event
        popup.style.left = `${event.clientX + 20}px`;
        popup.style.top = `${event.clientY - 100}px`;
        
        // Set content
        popup.innerHTML = `
            <div class="genius-popup-header">
                <h3 class="genius-popup-title">Job Handoff Score</h3>
                <button class="genius-popup-close">&times;</button>
            </div>
            <div class="telemetry-score">
                <div class="score-item">
                    <span class="score-label">Overall Score:</span>
                    <span class="score-value">
                        <div class="score-bar">
                            <div class="score-fill ${score.overallScore >= 80 ? 'high' : score.overallScore >= 60 ? 'medium' : 'low'}" style="width: ${score.overallScore}%"></div>
                        </div>
                        <span class="score-percentage">${score.overallScore}%</span>
                    </span>
                </div>
                <div class="score-item">
                    <span class="score-label">Distance to Job Site:</span>
                    <span class="score-value">
                        <div class="score-bar">
                            <div class="score-fill ${score.factors.distance >= 80 ? 'high' : score.factors.distance >= 60 ? 'medium' : 'low'}" style="width: ${score.factors.distance}%"></div>
                        </div>
                        <span class="score-percentage">${score.factors.distance}%</span>
                    </span>
                </div>
                <div class="score-item">
                    <span class="score-label">Time at Job Site:</span>
                    <span class="score-value">
                        <div class="score-bar">
                            <div class="score-fill ${score.factors.timeAtJob >= 80 ? 'high' : score.factors.timeAtJob >= 60 ? 'medium' : 'low'}" style="width: ${score.factors.timeAtJob}%"></div>
                        </div>
                        <span class="score-percentage">${score.factors.timeAtJob}%</span>
                    </span>
                </div>
                <div class="score-item">
                    <span class="score-label">Historical Pattern:</span>
                    <span class="score-value">
                        <div class="score-bar">
                            <div class="score-fill ${score.factors.historicalPattern >= 80 ? 'high' : score.factors.historicalPattern >= 60 ? 'medium' : 'low'}" style="width: ${score.factors.historicalPattern}%"></div>
                        </div>
                        <span class="score-percentage">${score.factors.historicalPattern}%</span>
                    </span>
                </div>
                <div class="score-item">
                    <span class="score-label">Driver Match:</span>
                    <span class="score-value">
                        <div class="score-bar">
                            <div class="score-fill ${score.factors.driverMatch >= 80 ? 'high' : score.factors.driverMatch >= 60 ? 'medium' : 'low'}" style="width: ${score.factors.driverMatch}%"></div>
                        </div>
                        <span class="score-percentage">${score.factors.driverMatch}%</span>
                    </span>
                </div>
                <div class="score-summary">
                    Confidence: <strong>${score.confidenceLevel}</strong>
                </div>
            </div>
        `;
        
        // Add close button handler
        const closeButton = popup.querySelector('.genius-popup-close');
        closeButton.addEventListener('click', () => {
            popup.remove();
        });
        
        // Show popup
        popup.style.display = 'block';
        
        // Log event
        this.logEvent('VisualDiagnostics', 'telemetry-score-viewed', {
            assetId: assetId,
            jobNumber: jobNumber,
            overallScore: score.overallScore,
            message: `Telemetry score viewed for asset ${assetId} on job ${jobNumber}`
        });
    }
    
    refreshDiagnostics() {
        // Update UI components
        this.updateEventTimelineUI();
        this.updateOverridesUI();
        
        // Clean up expired overrides
        this.cleanupExpiredOverrides();
    }
    
    cleanupExpiredOverrides() {
        const now = new Date();
        
        Object.keys(this.overrides).forEach(entityType => {
            Object.keys(this.overrides[entityType]).forEach(entityId => {
                const override = this.overrides[entityType][entityId];
                
                if (override.expirationTime && new Date(override.expirationTime) <= now) {
                    // Override has expired, remove it
                    this.removeOverride(entityType, entityId);
                    
                    console.log(`Override for ${entityType} ${entityId} expired and was removed`);
                }
            });
        });
    }
    
    setupMapInteractions() {
        // This would integrate with the map to show telemetry scores
        // when hovering over assets or job sites
        
        // For demonstration, we'll just log that this would happen
        console.log('Map interactions for diagnostic visualization would be set up here');
        
        // In a real implementation, this would add event listeners to map markers
        // Example pseudocode:
        // assetMarkers.forEach(marker => {
        //     marker.addEventListener('click', event => {
        //         this.showTelemetryScorePopup(marker.assetId, marker.jobNumber, event);
        //     });
        // });
    }
}

// Wait for GENIUS CORE to be available
document.addEventListener('DOMContentLoaded', function() {
    // Check if GENIUS CORE is loaded every 100ms
    const checkGeniusCore = setInterval(() => {
        if (window.GeniusCore) {
            clearInterval(checkGeniusCore);
            window.VisualDiagnostics = new VisualDiagnosticsSystem();
            console.log('Visual Diagnostics System connected to GENIUS CORE');
            
            // Log system boot event
            setTimeout(() => {
                window.VisualDiagnostics.logEvent('SystemManifest', 'system-boot', {
                    message: 'GENIUS CORE system fully initialized with Visual Diagnostics'
                });
                
                // Register a sample conflict for demonstration
                window.VisualDiagnostics.registerConflict(
                    'job-site-conflict',
                    { jobSite: '2024-019', assetId: 'EX-30' },
                    { 
                        message: 'Asset EX-30 is on job 2024-019 but driver is assigned to 2023-032',
                        severity: 'warning',
                        recommendedAction: 'Update driver assignment or move asset'
                    }
                );
                
                // Set up a sample override
                window.VisualDiagnostics.setOverride(
                    'job',
                    '2024-019',
                    'Special project with different tracking requirements',
                    new Date(Date.now() + 8 * 60 * 60 * 1000) // 8 hours from now
                );
            }, 2000);
        }
    }, 100);
});

console.log('GENIUS CORE Visual Diagnostics System Loaded');
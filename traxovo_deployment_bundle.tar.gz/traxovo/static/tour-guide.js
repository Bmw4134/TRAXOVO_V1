/**
 * TRAXOVO Contextual Onboarding Tour Guide
 * Intelligent tour system for fleet management platform
 */

class TRAXOVOTourGuide {
    constructor() {
        this.currentStep = 0;
        this.tourActive = false;
        this.tourData = [];
        this.overlay = null;
        this.tooltip = null;
        this.completedTours = this.getCompletedTours();
    }

    // Tour definitions for different pages
    getTourSteps(page) {
        const tours = {
            dashboard: [
                {
                    target: '.header',
                    title: 'Welcome to TRAXOVO',
                    content: 'Your complete fleet management platform. This header shows your current user and provides quick access to logout.',
                    position: 'bottom'
                },
                {
                    target: '.dashboard-grid',
                    title: 'Fleet Modules',
                    content: 'Access all fleet management tools from these organized modules. Each card provides specific functionality for different aspects of your fleet operations.',
                    position: 'top'
                },
                {
                    target: '[href="/fleet-map"]',
                    title: 'Fleet Map - Your Control Center',
                    content: 'This is your main fleet visualization tool. View all 701+ assets in real-time with filtering and search capabilities.',
                    position: 'top',
                    highlight: true
                },
                {
                    target: '[href="/attendance-matrix"]',
                    title: 'Driver Attendance',
                    content: 'Monitor driver attendance patterns, late starts, early ends, and job site presence with automated reporting.',
                    position: 'top'
                },
                {
                    target: '[href="/billing"]',
                    title: 'Billing Intelligence',
                    content: 'Track equipment billing, revenue analytics, and financial performance across all projects.',
                    position: 'top'
                }
            ],
            fleetMap: [
                {
                    target: '.fleet-header h1',
                    title: 'Fleet Map Overview',
                    content: 'Real-time view of all your fleet assets. Status indicators show Active (green), Idle (yellow), and Offline (red) equipment.',
                    position: 'bottom'
                },
                {
                    target: '.status-grid',
                    title: 'Fleet Status Summary',
                    content: 'Quick overview of your fleet status. Monitor how many assets are active, idle, or offline at a glance.',
                    position: 'bottom'
                },
                {
                    target: '.category-filters',
                    title: 'Equipment Categories',
                    content: 'Filter your fleet by equipment type. Click any category to focus on specific equipment types like excavators, trucks, or generators.',
                    position: 'bottom'
                },
                {
                    target: '.search-container',
                    title: 'Smart Search',
                    content: 'Quickly find specific equipment by name, ID, or operator. The search is intelligent and updates results in real-time.',
                    position: 'top'
                },
                {
                    target: '.fleet-grid',
                    title: 'Asset Grid View',
                    content: 'Each card shows detailed asset information including status, operator, location, and operational metrics. Click any asset for detailed information.',
                    position: 'top'
                }
            ],
            login: [
                {
                    target: '.login-form',
                    title: 'Secure Access',
                    content: 'TRAXOVO uses secure authentication. Use your assigned credentials to access the fleet management system.',
                    position: 'top'
                },
                {
                    target: '.demo-credentials',
                    title: 'Demo Access',
                    content: 'For demonstration purposes, you can use the provided test credentials to explore the system features.',
                    position: 'top'
                }
            ]
        };
        return tours[page] || [];
    }

    // Start tour for current page
    startTour(page) {
        if (this.isPageTourCompleted(page)) {
            if (!confirm('You\'ve already completed this tour. Would you like to take it again?')) {
                return;
            }
        }

        this.tourData = this.getTourSteps(page);
        if (this.tourData.length === 0) return;

        this.tourActive = true;
        this.currentStep = 0;
        this.createOverlay();
        this.showStep(0);
    }

    // Create overlay and tooltip elements
    createOverlay() {
        // Create semi-transparent overlay
        this.overlay = document.createElement('div');
        this.overlay.className = 'tour-overlay';
        this.overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 9998;
            pointer-events: none;
        `;
        document.body.appendChild(this.overlay);

        // Create tooltip
        this.tooltip = document.createElement('div');
        this.tooltip.className = 'tour-tooltip';
        this.tooltip.style.cssText = `
            position: fixed;
            max-width: 320px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            z-index: 9999;
            pointer-events: auto;
            border: 2px solid #007AFF;
        `;
        document.body.appendChild(this.tooltip);
    }

    // Show specific tour step
    showStep(stepIndex) {
        if (stepIndex >= this.tourData.length) {
            this.endTour();
            return;
        }

        const step = this.tourData[stepIndex];
        const targetElement = document.querySelector(step.target);
        
        if (!targetElement) {
            // Skip missing elements
            this.nextStep();
            return;
        }

        this.currentStep = stepIndex;
        this.highlightElement(targetElement, step.highlight);
        this.positionTooltip(targetElement, step);
        this.updateTooltipContent(step);
    }

    // Highlight target element
    highlightElement(element, extraHighlight = false) {
        // Remove previous highlights
        document.querySelectorAll('.tour-highlight').forEach(el => {
            el.classList.remove('tour-highlight', 'tour-extra-highlight');
        });

        // Add highlight to current element
        element.classList.add('tour-highlight');
        if (extraHighlight) {
            element.classList.add('tour-extra-highlight');
        }

        // Add styles if not already present
        if (!document.getElementById('tour-styles')) {
            const styles = document.createElement('style');
            styles.id = 'tour-styles';
            styles.textContent = `
                .tour-highlight {
                    position: relative;
                    z-index: 9997;
                    box-shadow: 0 0 0 4px rgba(0, 122, 255, 0.3) !important;
                    border-radius: 8px !important;
                }
                .tour-extra-highlight {
                    box-shadow: 0 0 0 4px rgba(0, 122, 255, 0.6) !important;
                    animation: tourPulse 2s infinite;
                }
                @keyframes tourPulse {
                    0%, 100% { box-shadow: 0 0 0 4px rgba(0, 122, 255, 0.6) !important; }
                    50% { box-shadow: 0 0 0 8px rgba(0, 122, 255, 0.3) !important; }
                }
                .tour-tooltip {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                }
            `;
            document.head.appendChild(styles);
        }
    }

    // Position tooltip relative to target element
    positionTooltip(element, step) {
        const rect = element.getBoundingClientRect();
        const tooltip = this.tooltip;
        const position = step.position || 'bottom';
        
        // Reset tooltip position
        tooltip.style.top = '';
        tooltip.style.bottom = '';
        tooltip.style.left = '';
        tooltip.style.right = '';
        tooltip.style.transform = '';

        switch (position) {
            case 'top':
                tooltip.style.bottom = `${window.innerHeight - rect.top + 15}px`;
                tooltip.style.left = `${rect.left + (rect.width / 2)}px`;
                tooltip.style.transform = 'translateX(-50%)';
                break;
            case 'bottom':
                tooltip.style.top = `${rect.bottom + 15}px`;
                tooltip.style.left = `${rect.left + (rect.width / 2)}px`;
                tooltip.style.transform = 'translateX(-50%)';
                break;
            case 'left':
                tooltip.style.top = `${rect.top + (rect.height / 2)}px`;
                tooltip.style.right = `${window.innerWidth - rect.left + 15}px`;
                tooltip.style.transform = 'translateY(-50%)';
                break;
            case 'right':
                tooltip.style.top = `${rect.top + (rect.height / 2)}px`;
                tooltip.style.left = `${rect.right + 15}px`;
                tooltip.style.transform = 'translateY(-50%)';
                break;
        }

        // Ensure tooltip stays within viewport
        const tooltipRect = tooltip.getBoundingClientRect();
        if (tooltipRect.right > window.innerWidth) {
            tooltip.style.left = `${window.innerWidth - tooltipRect.width - 20}px`;
            tooltip.style.transform = 'none';
        }
        if (tooltipRect.left < 0) {
            tooltip.style.left = '20px';
            tooltip.style.transform = 'none';
        }
    }

    // Update tooltip content
    updateTooltipContent(step) {
        const isLastStep = this.currentStep === this.tourData.length - 1;
        
        this.tooltip.innerHTML = `
            <div style="padding: 20px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                    <h3 style="margin: 0; color: #007AFF; font-size: 18px; font-weight: 600;">${step.title}</h3>
                    <span style="color: #8E8E93; font-size: 14px;">${this.currentStep + 1}/${this.tourData.length}</span>
                </div>
                <p style="margin: 0 0 20px 0; color: #1C1C1E; font-size: 16px; line-height: 1.4;">${step.content}</p>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <button onclick="tourGuide.skipTour()" style="
                        background: none; 
                        border: none; 
                        color: #8E8E93; 
                        font-size: 16px; 
                        cursor: pointer;
                        padding: 8px 0;
                    ">Skip Tour</button>
                    <div>
                        ${this.currentStep > 0 ? `
                            <button onclick="tourGuide.previousStep()" style="
                                background: #F2F2F7; 
                                border: none; 
                                color: #007AFF; 
                                padding: 12px 20px; 
                                border-radius: 8px; 
                                font-size: 16px; 
                                font-weight: 500;
                                cursor: pointer;
                                margin-right: 12px;
                            ">Previous</button>
                        ` : ''}
                        <button onclick="tourGuide.${isLastStep ? 'endTour()' : 'nextStep()'}" style="
                            background: #007AFF; 
                            border: none; 
                            color: white; 
                            padding: 12px 20px; 
                            border-radius: 8px; 
                            font-size: 16px; 
                            font-weight: 500;
                            cursor: pointer;
                        ">${isLastStep ? 'Finish' : 'Next'}</button>
                    </div>
                </div>
            </div>
        `;
    }

    // Navigation methods
    nextStep() {
        this.showStep(this.currentStep + 1);
    }

    previousStep() {
        if (this.currentStep > 0) {
            this.showStep(this.currentStep - 1);
        }
    }

    skipTour() {
        this.endTour();
    }

    endTour() {
        this.tourActive = false;
        
        // Mark tour as completed
        const page = this.getCurrentPage();
        this.markTourCompleted(page);
        
        // Clean up
        if (this.overlay) {
            this.overlay.remove();
            this.overlay = null;
        }
        if (this.tooltip) {
            this.tooltip.remove();
            this.tooltip = null;
        }
        
        // Remove highlights
        document.querySelectorAll('.tour-highlight').forEach(el => {
            el.classList.remove('tour-highlight', 'tour-extra-highlight');
        });
    }

    // Tour completion tracking
    getCurrentPage() {
        const path = window.location.pathname;
        if (path === '/' || path === '/dashboard') return 'dashboard';
        if (path === '/fleet-map' || path === '/map') return 'fleetMap';
        if (path === '/login') return 'login';
        return 'unknown';
    }

    getCompletedTours() {
        return JSON.parse(localStorage.getItem('traxovo_completed_tours') || '[]');
    }

    markTourCompleted(page) {
        if (!this.completedTours.includes(page)) {
            this.completedTours.push(page);
            localStorage.setItem('traxovo_completed_tours', JSON.stringify(this.completedTours));
        }
    }

    isPageTourCompleted(page) {
        return this.completedTours.includes(page);
    }

    // Auto-start tour for new users (subtle approach)
    autoStartTour() {
        const page = this.getCurrentPage();
        if (!this.isPageTourCompleted(page) && this.getTourSteps(page).length > 0) {
            // Just add the tour button, no popup
            this.showSubtleTourHint();
        }
    }

    showSubtleTourHint() {
        // Show a small, dismissible hint bubble instead of forced popup
        setTimeout(() => {
            const hint = document.createElement('div');
            hint.innerHTML = `
                <div style="display: flex; align-items: center; gap: 8px;">
                    <span>💡 New to this page?</span>
                    <button onclick="tourGuide.startTour('${this.getCurrentPage()}')" style="
                        background: #007AFF; 
                        color: white; 
                        border: none; 
                        padding: 4px 8px; 
                        border-radius: 4px; 
                        font-size: 12px;
                        cursor: pointer;
                    ">Tour</button>
                    <button onclick="this.parentElement.parentElement.remove()" style="
                        background: none; 
                        color: #666; 
                        border: none; 
                        font-size: 16px;
                        cursor: pointer;
                        padding: 2px;
                    ">×</button>
                </div>
            `;
            hint.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                background: white;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 12px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                z-index: 1000;
                font-size: 14px;
                max-width: 250px;
            `;
            document.body.appendChild(hint);
            
            // Auto-hide after 10 seconds
            setTimeout(() => {
                if (hint.parentElement) {
                    hint.remove();
                }
            }, 10000);
        }, 2000);
    }
}

// Initialize tour guide
const tourGuide = new TRAXOVOTourGuide();

// Initialize when page loads (prevent duplicate initialization)
if (!window.tourGuideInitialized) {
    window.tourGuideInitialized = true;
    
    document.addEventListener('DOMContentLoaded', () => {
        tourGuide.autoStartTour();
        addSubtleTourButton();
    });
}

// Add subtle tour button
function addSubtleTourButton() {
    const page = tourGuide.getCurrentPage();
    if (tourGuide.getTourSteps(page).length === 0) return;
    
    const button = document.createElement('button');
    button.innerHTML = '?';
    button.title = 'Take a quick tour';
    button.onclick = () => tourGuide.startTour(page);
    button.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #007AFF;
        color: white;
        border: none;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        z-index: 1000;
        box-shadow: 0 2px 8px rgba(0, 122, 255, 0.3);
        opacity: 0.7;
        transition: opacity 0.2s ease;
    `;
    
    button.addEventListener('mouseenter', () => button.style.opacity = '1');
    button.addEventListener('mouseleave', () => button.style.opacity = '0.7');
    
    document.body.appendChild(button);
}
/**
 * TRAXOVO Dashboard JavaScript
 * Enhanced functionality for real-time updates and interactions
 */

class TRAXOVODashboard {
    constructor() {
        this.refreshInterval = 30000; // 30 seconds
        this.charts = {};
        this.isRefreshing = false;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.startAutoRefresh();
        this.initializeNotifications();
        console.log('TRAXOVO Dashboard initialized');
    }

    setupEventListeners() {
        // Refresh buttons
        document.querySelectorAll('[onclick*="refresh"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                this.refreshData();
            });
        });

        // Export buttons
        document.querySelectorAll('[onclick*="export"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleExport(e.target);
            });
        });

        // Card hover effects
        document.querySelectorAll('.metric-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                this.animateValue(card.querySelector('.metric-value'));
            });
        });
    }

    async refreshData() {
        if (this.isRefreshing) return;
        
        this.isRefreshing = true;
        this.showNotification('Refreshing data...', 'info');

        try {
            const endpoints = [
                '/api/assets',
                '/api/metrics'
            ];

            const responses = await Promise.all(
                endpoints.map(endpoint => fetch(endpoint))
            );

            const data = await Promise.all(
                responses.map(response => response.json())
            );

            this.updateKPICards(data[1]);
            this.updateCharts(data);
            this.showNotification('Data refreshed successfully', 'success');

        } catch (error) {
            console.error('Refresh failed:', error);
            this.showNotification('Failed to refresh data', 'error');
        } finally {
            this.isRefreshing = false;
        }
    }

    updateKPICards(metricsData) {
        if (!metricsData) return;

        // Update metric values with animation
        const metrics = {
            'total_assets': metricsData.total_assets,
            'fleet_utilization': metricsData.fleet_utilization,
            'cost_savings': metricsData.cost_savings,
            'efficiency_score': metricsData.efficiency_score
        };

        Object.entries(metrics).forEach(([key, value]) => {
            const element = document.querySelector(`[data-metric="${key}"]`);
            if (element) {
                this.animateValueChange(element, value);
            }
        });
    }

    updateCharts(data) {
        // Update chart data if charts exist
        if (typeof Chart !== 'undefined' && this.charts.performance) {
            this.charts.performance.update();
        }
        if (typeof Chart !== 'undefined' && this.charts.distribution) {
            this.charts.distribution.update();
        }
    }

    animateValue(element) {
        if (!element) return;
        
        element.style.transform = 'scale(1.1)';
        element.style.transition = 'transform 0.3s ease';
        
        setTimeout(() => {
            element.style.transform = 'scale(1)';
        }, 300);
    }

    animateValueChange(element, newValue) {
        if (!element) return;

        const currentValue = parseFloat(element.textContent) || 0;
        const duration = 1000;
        const steps = 60;
        const increment = (newValue - currentValue) / steps;
        let current = currentValue;
        let step = 0;

        const animation = setInterval(() => {
            current += increment;
            step++;

            if (element.dataset.format === 'currency') {
                element.textContent = `$${Math.round(current).toLocaleString()}`;
            } else if (element.dataset.format === 'percentage') {
                element.textContent = `${current.toFixed(1)}%`;
            } else {
                element.textContent = Math.round(current).toLocaleString();
            }

            if (step >= steps) {
                clearInterval(animation);
                if (element.dataset.format === 'currency') {
                    element.textContent = `$${Math.round(newValue).toLocaleString()}`;
                } else if (element.dataset.format === 'percentage') {
                    element.textContent = `${newValue.toFixed(1)}%`;
                } else {
                    element.textContent = Math.round(newValue).toLocaleString();
                }
            }
        }, duration / steps);
    }

    async handleExport(button) {
        const exportType = button.textContent.toLowerCase();
        this.showNotification(`Preparing ${exportType} export...`, 'info');

        try {
            let endpoint = '/api/assets';
            let filename = 'traxovo_data.json';

            if (exportType.includes('csv')) {
                endpoint = '/api/assets';
                filename = 'traxovo_data.csv';
            } else if (exportType.includes('metrics')) {
                endpoint = '/api/metrics';
                filename = 'traxovo_metrics.json';
            }

            const response = await fetch(endpoint);
            const data = await response.json();

            if (filename.endsWith('.csv')) {
                this.downloadCSV(data, filename);
            } else {
                this.downloadJSON(data, filename);
            }

            this.showNotification('Export completed successfully', 'success');

        } catch (error) {
            console.error('Export failed:', error);
            this.showNotification('Export failed', 'error');
        }
    }

    downloadJSON(data, filename) {
        const blob = new Blob([JSON.stringify(data, null, 2)], { 
            type: 'application/json' 
        });
        this.downloadBlob(blob, filename);
    }

    downloadCSV(data, filename) {
        if (!Array.isArray(data) || data.length === 0) {
            this.showNotification('No data to export', 'warning');
            return;
        }

        const headers = Object.keys(data[0]);
        const csvContent = [
            headers.join(','),
            ...data.map(row => 
                headers.map(field => 
                    JSON.stringify(row[field] || '')
                ).join(',')
            )
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv' });
        this.downloadBlob(blob, filename);
    }

    downloadBlob(blob, filename) {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification alert alert-${type}`;
        notification.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <span>${message}</span>
                <button type="button" class="btn-close btn-close-white" onclick="this.parentElement.parentElement.remove()"></button>
            </div>
        `;

        document.body.appendChild(notification);

        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

    startAutoRefresh() {
        setInterval(() => {
            if (!this.isRefreshing && document.visibilityState === 'visible') {
                this.refreshData();
            }
        }, this.refreshInterval);
    }

    initializeNotifications() {
        // Check for system alerts
        this.checkSystemHealth();
        
        // Check every 5 minutes
        setInterval(() => {
            this.checkSystemHealth();
        }, 300000);
    }

    async checkSystemHealth() {
        try {
            const response = await fetch('/health');
            const health = await response.json();

            if (health.status !== 'healthy') {
                this.showNotification('System health warning detected', 'warning');
            }
        } catch (error) {
            console.error('Health check failed:', error);
        }
    }

    // Utility function for copying API URLs
    copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            this.showNotification('API URL copied to clipboard', 'success');
        }).catch(() => {
            this.showNotification('Failed to copy URL', 'error');
        });
    }

    // Format numbers for display
    formatNumber(num, type = 'number') {
        switch (type) {
            case 'currency':
                return new Intl.NumberFormat('en-US', {
                    style: 'currency',
                    currency: 'USD',
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0
                }).format(num);
            case 'percentage':
                return `${num.toFixed(1)}%`;
            case 'decimal':
                return num.toFixed(2);
            default:
                return num.toLocaleString();
        }
    }
}

// Initialize dashboard when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.traxovoDashboard = new TRAXOVODashboard();
});

// Global functions for backward compatibility
function refreshAssetData() {
    if (window.traxovoDashboard) {
        window.traxovoDashboard.refreshData();
    }
}

function exportToCSV() {
    if (window.traxovoDashboard) {
        window.traxovoDashboard.handleExport({ textContent: 'Export to CSV' });
    }
}

function copyApiUrl() {
    if (window.traxovoDashboard) {
        const url = window.location.origin + '/api/assets';
        window.traxovoDashboard.copyToClipboard(url);
    }
}